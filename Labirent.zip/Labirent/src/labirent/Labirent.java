/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 * @file Labirent
 * @description Labirentte oyuncu B noktasınan E noktasına en az hamlede
 * ulaşmaya çalışırken duvarlar, mayınlar ve bonuslar ile karşılaşıyor.
 * @assignment 1
 * @date 14.12.2023
 * @author Esma Nur Bezirkan
 */
package labirent;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author bezir
 */
public class Labirent {

    private static int F_bonus = 0;
    private static int R_bonus = 0; //labirentte bonusları toplarken kullanılan değişken
    private static int H_bonus = 0;
    private static int T_bonus = 0;

    private static int toplamFBonus = 5;  //labirentte bulunan toplam f sayısı 
    private static int toplamRBonus = 5;  //bu değerler bonuslar kazanıldıktan sonra azalır
    private static int toplamHBonus = 5;  //random labirent yazdırıken bu sayıya eşit olana kadar labirente bonus ya da mayın atar
    private static int toplamTBonus = 5;
    private static int toplamMayin = 10;

    private static int hamleSayisi = 0;

    private static int randomF_bonus = 0;
    private static int randomR_bonus = 0;
    private static int randomH_bonus = 0;  //labirent random oluştururken bu değişkenler kullanılır
    private static int randomT_bonus = 0;
    private static int random_mayin = 0;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        char[][] labirent = {
            {'#', '!', '.', '.', 'R', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.'},
            {'.', '.', '#', '.', '.', '.', '#', '.', 'H', '.', '.', '.', '.', '.', '!'},
            {'F', '.', '.', '.', '#', '.', '!', '.', '.', 'R', '.', '.', '#', '#', '.'},
            {'.', '.', '#', '.', '.', '#', '.', '.', '.', '.', 'F', '.', '.', '.', '.'},
            {'.', '!', '.', '.', '#', '.', '#', '.', '#', '.', '.', '#', '.', '.', '.'},
            {'.', '.', 'H', '.', '.', '!', '.', '.', 'H', '.', '.', 'F', '.', '.', 'R'},
            {'#', '#', '#', '#', '.', '.', '#', '.', '.', '.', 'T', '.', '.', '.', 'E'},
            {'.', '.', '#', '.', 'F', '.', '#', '#', '.', '#', '#', '#', '#', '.', '.'},
            {'.', '#', '.', '.', '.', '.', '!', '.', '#', '.', '.', '.', '#', '.', '.'},
            {'.', 'T', 'T', '.', '#', '#', '.', '.', '.', '.', 'T', '.', '.', '.', 'R'},
            {'.', '.', '.', '#', '.', '.', '.', '#', '.', '#', '.', '#', '.', 'T', '.'},
            {'B', '.', '#', '.', '.', '!', '.', '!', '.', '.', '.', '.', '.', '.', '#'},
            {'.', '.', '.', 'F', '!', '.', '.', '.', 'H', '.', '.', 'R', '.', '.', '.'},
            {'.', '.', 'H', '.', '.', '.', '!', '.', '.', '.', '#', '.', '.', '#', '.'},
            {'.', '.', '.', '#', '.', '.', '#', '.', '#', '.', '#', '.', '.', '#', '#'}};

        System.out.println("Labirent Oyunu:");
        int bRow = -1;    //b noktasının konumunu bul
        int bCol = 0;
        for (int i = 0; i < labirent.length; i++) {
            if (labirent[i][0] == 'B') {
                bRow = i;
                break;
            }
        }
        if (bRow == -1) {
            System.out.println("B noktası bulunmamaktadır.");
        }

        System.out.println("B harfinin bulundugu konum: (" + bRow + "." + bCol + ")");

        int eRow = -1; //e noktasının konumu
        int eCol = labirent[0].length - 1;

        for (int i = 0; i < labirent.length; i++) {
            if (labirent[i][eCol] == 'E') {
                eRow = i;
                break;

            }
        }
        if (eRow == -1) {
            System.out.println("E noktası bulunmamaktadır.");
        }

        System.out.println("E harfinin bulundugu konum: (" + eRow + "." + eCol + ")");

        int row = bRow; //başlangıç konumu brow a eşit oldğu için devamında kullanacağım konuma eşitliyotum
        int col = bCol;
        while (labirent[row][col] != 'E') {

            if (hamleSayisi % 5 == 0 && hamleSayisi != 0) { //random labirent atamasını adım sayısı beşin katlarında yapmalı
                labirent = randomLabirent(labirent, row, col); //labirentin random dağıtılmış halini ekrana yazdırır
            }

            for (int i = 0; i < labirent.length; i++) {        //labirenti ekrana yazdır
                for (int j = 0; j < labirent[i].length; j++) {
                    System.out.print(labirent[i][j] + "  ");
                }
                System.out.println();
            }

            System.out.print("W, A, S, D karakterlerinden birini giriniz ya da bonus kullanmak için + karakterine basınız. Çıkış için \"EXİT\" yazınız: \n ");
            String move = input.next().toUpperCase();

            switch (move) {
                case "W":
                    System.out.println("Girdi: W");
                    if (row > 0) {

                        if (labirent[row - 1][col] == '#') {
                            if (duvar_kaldırma()) {
                                System.out.println("Duvarla karşılaştın.Bonus kullanarak duvarı kırdınız.");
                                labirent[row - 1][col] = '.';
                                row--;
                                hamleSayisi++;
                            }
                        } else if (labirent[row - 1][col] == '!') {
                            if (mayin_cozme()) {
                                System.out.println("Mayınla karşılaştın. Bonus kullanarak mayını çözdünüz.");
                                labirent[row - 1][col] = '.';
                                row--;
                                hamleSayisi++;
                            } else {
                                labirent[row - 1][col] = '.';
                                labirent = randomLabirent(labirent, row, col);
                            }
                        } else if (labirent[row - 1][col] == 'T') {
                            System.out.println("T bonusu kazanıldı");
                            T_bonus++;
                            toplamTBonus--;
                            labirent[row - 1][col] = '.';
                            row--;
                            hamleSayisi++;
                        } else if (labirent[row - 1][col] == 'H') {
                            System.out.println("H bonusu kazanıldı");
                            H_bonus++; //kullanıcıda olan bonus sayısı artar
                            toplamHBonus--; //H bonusu alınıp '.' ile değiştirildiği için labirentte olan H bonus sayısı bir azalır
                            labirent[row - 1][col] = '.';
                            row--;
                            hamleSayisi++;
                        } else if (labirent[row - 1][col] == 'R') {
                            System.out.println("R bonusu kazanıldı");
                            R_bonus++;
                            toplamRBonus--;
                            labirent[row - 1][col] = '.';
                            row--;
                            hamleSayisi++;
                        } else if (labirent[row - 1][col] == 'F') {
                            System.out.println("F bonusu kazanıldı");
                            F_bonus++;
                            toplamFBonus--;
                            labirent[row - 1][col] = '.';
                            row--;
                            hamleSayisi++;
                        } else {
                            row--;
                            hamleSayisi++;
                        }
                    } else {
                        System.out.println("Labirent sınırları dışına çıkamazsınız ");

                    }
                    System.out.println("Bulunduğunuz konum ( " + row + "," + col + ").");
                    System.out.println("Adım sayısı: " + hamleSayisi);

                    break;
                case "A":
                    System.out.println("Girdi: A");
                    if (col > 0) {
                        if (labirent[row][col - 1] == '#') {
                            if (duvar_kaldırma()) {
                                System.out.println("Duvarla karşılaştın.Bonus kullanarak duvarı kırdınız.");
                                labirent[row][col - 1] = '.';
                                col--;
                                hamleSayisi++;
                            }
                        } else if (labirent[row][col - 1] == '!') {
                            if (mayin_cozme()) {
                                System.out.println("Mayınla karşılaştın. Bonus kullanarak mayını çözdünüz.");
                                labirent[row][col - 1] = '.';
                                col--;
                                hamleSayisi++;
                            } else {
                                labirent[row][col - 1] = '.';
                                labirent = randomLabirent(labirent, row, col);
                            }
                        } else if (labirent[row][col - 1] == 'T') {
                            System.out.println("T bonusu kazanıldı");
                            T_bonus++;
                            toplamTBonus--;
                            labirent[row][col - 1] = '.';
                            col--;
                            hamleSayisi++;
                        } else if (labirent[row][col - 1] == 'H') {
                            System.out.println("H bonusu kazanıldı");
                            H_bonus++;
                            toplamHBonus--;
                            labirent[row][col - 1] = '.';
                            col--;
                            hamleSayisi++;
                        } else if (labirent[row][col - 1] == 'R') {
                            System.out.println("T bonusu kazanıldı");
                            R_bonus++;
                            toplamRBonus--;
                            labirent[row][col - 1] = '.';
                            col--;
                            hamleSayisi++;
                        } else if (labirent[row][col - 1] == 'F') {
                            System.out.println("F bonusu kazanıldı");
                            F_bonus++;
                            toplamFBonus--;
                            labirent[row][col - 1] = '.';
                            col--;
                            hamleSayisi++;
                        } else {
                            col--;
                            hamleSayisi++;
                        }
                    } else {
                        System.out.println("Labirent sınırları dışına çıkamazsınız ");
                    }
                    System.out.println("Bulunduğunuz konum ( " + row + "," + col + ").");
                    System.out.println("Adım sayısı: " + hamleSayisi);
                    break;
                case "S":
                    System.out.println("Girdi: S");
                    if (row < labirent.length - 1) {
                        if (labirent[row + 1][col] == '#') {
                            if (duvar_kaldırma()) {
                                System.out.println("Duvarla karşılaştın.Bonus kullanarak duvarı kırdınız.");
                                labirent[row + 1][col] = '.';
                                row++;
                                hamleSayisi++;
                            }
                        } else if (labirent[row + 1][col] == '!') {
                            if (mayin_cozme()) {
                                System.out.println("Mayınla karşılaştın. Bonus kullanarak mayını çözdünüz.");
                                labirent[row + 1][col] = '.';
                                row++;
                                hamleSayisi++;
                            } else {
                                labirent[row + 1][col] = '.';
                                labirent = randomLabirent(labirent, row, col);
                            }
                        } else if (labirent[row + 1][col] == 'T') {
                            System.out.println("T bonusu kazanıldı");
                            T_bonus++;
                            toplamTBonus--;
                            labirent[row + 1][col] = '.';
                            row++;
                            hamleSayisi++;
                        } else if (labirent[row + 1][col] == 'H') {
                            System.out.println("H bonusu kazanıldı");
                            H_bonus++;
                            toplamHBonus--;
                            labirent[row + 1][col] = '.';
                            row++;
                            hamleSayisi++;
                        } else if (labirent[row + 1][col] == 'R') {
                            System.out.println("R bonusu kazanıldı");
                            R_bonus++;
                            toplamRBonus--;
                            labirent[row + 1][col] = '.';
                            row++;
                            hamleSayisi++;
                        } else if (labirent[row + 1][col] == 'F') {
                            System.out.println("F bonusu kazanıldı");
                            F_bonus++;
                            toplamFBonus--;
                            labirent[row + 1][col] = '.';
                            row++;
                            hamleSayisi++;
                        } else {
                            row++;
                            hamleSayisi++;
                        }
                    } else {
                        System.out.println("Labirent sınırları dışına çıkamazsınız ");
                    }
                    System.out.println("Bulunduğunuz konum ( " + row + "," + col + ").");
                    System.out.println("Adım sayısı: " + hamleSayisi);
                    break;
                case "D":
                    System.out.println("Girdi: D");
                    if (col < labirent[row].length - 1) {
                        if (labirent[row][col + 1] == '#') {
                            if (duvar_kaldırma()) {
                                System.out.println("Duvarla karşılaştın.Bonus kullanarak duvarı kırdınız.");
                                labirent[row][col + 1] = '.';
                                col++;
                                hamleSayisi++;
                            }
                        } else if (labirent[row][col + 1] == '!') {
                            if (mayin_cozme()) {
                                System.out.println("Mayınla karşılaştın. Bonus kullanarak mayını çözdünüz.");
                                labirent[row][col + 1] = '.';
                                col++;
                                hamleSayisi++;
                            } else {
                                labirent[row][col + 1] = '.'; 
                                labirent = randomLabirent(labirent, row, col);
                            }
                        } else if (labirent[row][col + 1] == 'T') {
                            System.out.println("T bonusu kazanıldı");
                            T_bonus++;
                            toplamTBonus--;
                            labirent[row][col + 1] = '.';
                            col++;
                            hamleSayisi++;
                        } else if (labirent[row][col + 1] == 'H') {
                            System.out.println("H bonusu kazanıldı");
                            H_bonus++;
                            toplamHBonus--;
                            labirent[row][col + 1] = '.';
                            col++;
                            hamleSayisi++;
                        } else if (labirent[row][col + 1] == 'R') {
                            System.out.println("R bonusu kazanıldı");
                            R_bonus++;
                            toplamRBonus--;
                            labirent[row][col + 1] = '.';
                            col++;
                            hamleSayisi++;
                        } else if (labirent[row][col + 1] == 'F') {
                            System.out.println("F bonusu kazanıldı");
                            F_bonus++;
                            toplamFBonus--;
                            labirent[row][col + 1] = '.';
                            col++;
                            hamleSayisi++;
                        } else {
                            col++;
                            hamleSayisi++;
                        }
                    } else {
                        System.out.println("Labirent sınırları dışına çıkamazsınız ");
                    }
                    System.out.println("Bulunduğunuz konum ( " + row + "," + col + ").");
                    System.out.println("Adım sayısı: " + hamleSayisi);
                    break;

                case "+":
                    System.out.println("Girdi : +");
                    System.out.print("Kullanmak istediğin bonusu seçiniz(T,H): ");
                    char bonus = input.next().toUpperCase().charAt(0);

                    while (bonus != 'T' && bonus != 'H') { 
                        System.out.println("Geçersiz giriş girdiniz. Lütfen T,H bonuslarından birini giriniz.");
                        bonus = input.next().toUpperCase().charAt(0);
                    }

                    if (bonus == 'T') {
                        System.out.println("Seçilen bonus : " + bonus);
                        if (T_bonus > 0) {
                            System.out.println("T bonus sayısı : " + T_bonus);
                            System.out.println("T bonusu kullanıldı.");
                            T_bonus--;
                            int[] isinlanma = labirent_isinlanma();
                            row = isinlanma[0];
                            col = isinlanma[1];
                            while (labirent[row][col] == '#' || labirent[row][col] == '!') { //ışınlanmak istenilen yer kontrol edilir
                                System.out.println("Işınlanmak istediğiniz noktada duvar veya mayın bulunmaktadır ışınlanamazsınız.");
                                isinlanma = labirent_isinlanma();
                                row = isinlanma[0];
                                col = isinlanma[1];
                            }
                        } else {
                            System.out.println("T bonusunuz bulunmamaktadır");
                            hamleSayisi++;
                            System.out.println("Adım sayısı: " + hamleSayisi);
                        }

                        if (labirent[row][col] == 'T') {
                            T_bonus++;
                            toplamTBonus--;
                            labirent[row][col] = '.';
                            System.out.println("T bonus sayısı: " + T_bonus);

                        } else if (labirent[row][col] == 'R') {
                            R_bonus++;
                            toplamRBonus--;
                            labirent[row][col] = '.';
                            System.out.println("R bonusu alındı.R bonus sayısı: " + R_bonus);

                        } else if (labirent[row][col] == 'F') {
                            F_bonus++;
                            toplamFBonus--;
                            labirent[row][col] = '.';
                            System.out.println("F bonusu alındı.F bonus sayısı: " + F_bonus);

                        } else if (labirent[row][col] == 'H') {
                            H_bonus++;
                            toplamHBonus--;
                            labirent[row][col] = '.';
                            System.out.println("H bonusu alındı.H bonus sayısı: " + H_bonus);
                        }
                    } else if (bonus == 'H') {
                        if (H_bonus > 0) {
                            System.out.println("Seçilen bonus : " + bonus);
                            System.out.println("H bonusunu kullandınız. Adım sayınız 2 azaldı.");
                            hamleSayisi = hamleSayisi - 2;
                            if (hamleSayisi < 0) {
                                hamleSayisi = 0; //adım sayısı negatif olmaması için kontrol yapılmalı
                            }
                            H_bonus--;
                            hamleSayisi++;
                            System.out.println("Adım sayısı: " + hamleSayisi);
                        } else {
                            System.out.println("H bonusunuz bulunmamaktadır.");
                            hamleSayisi++;
                            System.out.println("Adım sayısı: " + hamleSayisi);
                        }
                    } else {
                        System.out.print("Geçersiz giriş  girdiniz T,H bonuslarından biriniz giriniz: ");
                    }
                    System.out.println("Bulunduğunuz konum ( " + row + "," + col + ").");

                    break;
                case "EXİT":
                    System.out.println("Oyundan çıkış yaptınız.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Geçersiz giriş.W, A, S, D karakterlerinden birini giriniz ya da bonus kullanmak için + karakterine basınız. Çıkış için \"EXİT\" yazınız: \n ");
                    break;
            }
            if (labirent[row][col] == 'E') {
                System.out.println("Tebrikler.Çıkışa ulaştınız");

            }
        }
    }

    public static char[][] randomLabirent(char labirent[][], int anlık_row, int anlık_col) {
        Random random = new Random();

        for (int i = 0; i < 15; i++) {   //labirentte #,B,E dışında her karakteri "." yapar
            for (int j = 0; j < 15; j++) {
                if (labirent[i][j] != '#' && labirent[i][j] != 'B' && labirent[i][j] != 'E') {
                    labirent[i][j] = '.';
                }
            }

        }

        for (int i = 0; i < 10; i++) {
            while (random_mayin != toplamMayin) { //random atanan mayın sayısı ekranda bulunan mayın sayısına eşit olana kadar döngü çalışmaya devam eder
                int row = random.nextInt(15);
                int col = random.nextInt(15);
                if (row != anlık_row && col != anlık_col) {
                    if (labirent[row][col] != '#' && labirent[row][col] != 'B' && labirent[row][col] != 'E') {
                        labirent[row][col] = '!';
                        random_mayin++;
                    }
                }
            }
        }

        for (int i = 0; i < 5; i++) {
            while (randomR_bonus != toplamRBonus) {
                int row = random.nextInt(15);
                int col = random.nextInt(15);
                if (row != anlık_row && col != anlık_col) {
                    if (labirent[row][col] != '#' && labirent[row][col] != '!' && labirent[row][col] != 'B' && labirent[row][col] != 'E') {
                        labirent[row][col] = 'R';
                        randomR_bonus++;
                    }

                }
            }
        }

        for (int i = 0; i < 5; i++) {
            while (randomT_bonus != toplamTBonus) {
                int row = random.nextInt(15);
                int col = random.nextInt(15);
                if (row != anlık_row && col != anlık_col) {
                    if (labirent[row][col] != '#' && labirent[row][col] != '!' && labirent[row][col] != 'B' && labirent[row][col] != 'E' && labirent[row][col] != 'R') {
                        labirent[row][col] = 'T';
                        randomT_bonus++;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            while (randomF_bonus != toplamFBonus) {
                int row = random.nextInt(15);
                int col = random.nextInt(15);
                if (row != anlık_row && col != anlık_col) {
                    if (labirent[row][col] != '#' && labirent[row][col] != '!' && labirent[row][col] != 'B' && labirent[row][col] != 'E' && labirent[row][col] != 'R' && labirent[row][col] != 'T') {
                        labirent[row][col] = 'F';
                        randomF_bonus++;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            while (randomH_bonus != toplamHBonus) { //random atanan bonus sayısı ekranda bulunan bonus sayısına eşit olana kadar kod çalışır
                int row = random.nextInt(15);
                int col = random.nextInt(15);
                if (row != anlık_row && col != anlık_col) {
                    if (labirent[row][col] != '#' && labirent[row][col] != '!' && labirent[row][col] != 'B' && labirent[row][col] != 'E' && labirent[row][col] != 'R' && labirent[row][col] != 'T' && labirent[row][col] != 'F') {
                        labirent[row][col] = 'H';
                        randomH_bonus++; //ekrana yazılan bonus sayısı artar
                    }
                }
            }
        }
        randomR_bonus = 0;
        randomH_bonus = 0;
        randomT_bonus = 0; //fonksiyon her çağırıldığında değerlerin sıfırlanması 
        randomF_bonus = 0;
        random_mayin = 0;
        return labirent;

    }

    public static boolean mayin_cozme() {
        if (F_bonus > 0) {
            System.out.println("F bonusu kullanıldı");
            F_bonus--;
            toplamMayin--; //labirentte bulunan mayın sayısı azalır
            return true;
        } else {
            System.out.println("Bonusunuz yok. Mayın patladı");
            hamleSayisi = hamleSayisi + 5;
            hamleSayisi++;
            System.out.println("Adım sayınız 5 arttı.Yeni adım sayınız : " + hamleSayisi);
            toplamMayin--; //labirentte bulunan mayın sayısı azalır
            return false;
        }
    }

    public static boolean duvar_kaldırma() {
        if (R_bonus > 0) {
            System.out.println("R bonusu kullanıldı");
            R_bonus--;
            return true;
        } else {
            hamleSayisi++;
            System.out.println("Bonusunuz yok.Duvarı geçemezsiniz Lütfen başka yöne ilerleyiniz.");
            return false;
        }
    }

    public static int[] labirent_isinlanma() {
        System.out.println("Işınlanmak istediğiniz kordinatları giriniz");
        int[] isinlanma = new int[2];
        int satir = new Scanner(System.in).nextInt();  
        int sutun = new Scanner(System.in).nextInt();
        while (satir < 0 || satir > 14 || sutun < 0 || sutun > 14) { //girilen satır ve sütun değerlerinin labirent sınırları içinde olması kontrol edilir
            System.out.println("Geçersiz giriş.lütfen labirent sınırları içinde değerler giriniz.");
            satir = new Scanner(System.in).nextInt();
            sutun = new Scanner(System.in).nextInt();
        }
        isinlanma[0] = satir;
        isinlanma[1] = sutun;
        hamleSayisi++;
        System.out.println("Adım sayısı : " + hamleSayisi);
        return isinlanma;
    }
}
